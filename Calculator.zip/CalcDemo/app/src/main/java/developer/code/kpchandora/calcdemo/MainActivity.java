package developer.code.kpchandora.calcdemo;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    @BindView(R.id.button_seven)
    Button buttonSeven;
    @BindView(R.id.button_eight)
    Button buttonEight;
    @BindView(R.id.button_nine)
    Button buttonNine;
    @BindView(R.id.button_divide)
    Button buttonDivide;
    @BindView(R.id.button_four)
    Button buttonFour;
    @BindView(R.id.button_five)
    Button buttonFive;
    @BindView(R.id.button_six)
    Button buttonSix;
    @BindView(R.id.button_multiply)
    Button buttonMultiply;
    @BindView(R.id.button_one)
    Button buttonOne;
    @BindView(R.id.button_two)
    Button buttonTwo;
    @BindView(R.id.button_three)
    Button buttonThree;
    @BindView(R.id.button_subtract)
    Button buttonSubtract;
    @BindView(R.id.button_dot)
    Button buttonDot;
    @BindView(R.id.button_zero)
    Button buttonZero;
    @BindView(R.id.button_equals)
    Button buttonEquals;
    @BindView(R.id.button_add)
    Button buttonAdd;
    @BindView(R.id.linearLayout)
    LinearLayout linearLayout;
    @BindView(R.id.button_clear)
    Button buttonClear;
    @BindView(R.id.resultTextView)
    TextView resultTextView;

    private double result;
    private StringBuilder builder;
    private StringBuilder operationBuilder;

    private static final int OPERATION_ADD = 0;
    private static final int OPERATION_SUB = 1;
    private static final int OPERATION_MUL = 2;
    private static final int OPERATION_DIV = 3;
    private boolean containsDot;
    private boolean isCalculated;
    private ArrayList<Integer> operationList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        result = 0;
        containsDot = false;
        isCalculated = false;
        builder = new StringBuilder();
        operationBuilder = new StringBuilder();
        operationList = new ArrayList<>();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        startActivity(new Intent(MainActivity.this, ResultActivity.class));
        return super.onOptionsItemSelected(item);
    }

    public void onClick(View view) {

        String text = "";
        int builderCount = builder.length();
        String splitText = "";

        switch (view.getId()) {
            case R.id.button_one:
                text = "1";
                break;
            case R.id.button_two:
                text = "2";
                break;
            case R.id.button_three:
                text = "3";
                break;
            case R.id.button_four:
                text = "4";
                break;
            case R.id.button_five:
                text = "5";
                break;
            case R.id.button_six:
                text = "6";
                break;
            case R.id.button_seven:
                text = "7";
                break;
            case R.id.button_eight:
                text = "8";
                break;
            case R.id.button_nine:
                text = "9";
                break;
            case R.id.button_zero:
                text = "0";
                break;
            case R.id.button_add:
                if (builderCount != 0) {
                    if (checkOperationChar(OPERATION_ADD)) {
                        text = "+";
                        removeLastChar("+");
                    } else {
                        text = "+";
                        splitText = ":";
                        operationList.add(OPERATION_ADD);
                    }
                    containsDot = false;
                }
                break;
            case R.id.button_subtract:
                if (builderCount != 0) {
                    if (checkOperationChar(OPERATION_SUB)) {
                        text = "-";
                        removeLastChar("-");
                    } else {
                        text = "-";
                        splitText = ":";
                        operationList.add(OPERATION_SUB);
                    }
                    containsDot = false;
                }
                break;
            case R.id.button_multiply:
                if (builderCount != 0) {
                    if (checkOperationChar(OPERATION_MUL)) {
                        text = "×";
                        removeLastChar("×");
                    } else {
                        text = "×";
                        splitText = ":";
                        operationList.add(OPERATION_MUL);
                    }
                    containsDot = false;
                }
                break;
            case R.id.button_divide:
                if (builderCount != 0) {
                    if (checkOperationChar(OPERATION_DIV)) {
                        text = "÷";
                        removeLastChar("÷");
                    } else {
                        text = "÷";
                        splitText = ":";
                        operationList.add(OPERATION_DIV);
                    }
                    containsDot = false;
                }
                break;
            case R.id.button_dot:
                if (!containsDot) {
                    text = ".";
                    containsDot = true;
                }
                break;
            case R.id.button_equals:
                double result = doCalculation();
//                double result = evaluatePostfix(infixToPostfix(builder.toString()));
                resultTextView.setText(result + "");
                if (result != 0 || !builder.toString().equals("")) {
                    insertData(result);
                }
                operationList.clear();
                operationBuilder.setLength(0);
                builder.setLength(0);
                return;
            case R.id.button_clear:
                builder.setLength(0);
                operationList.clear();
                operationBuilder.setLength(0);
                text = "clear";
                containsDot = false;
                isCalculated = true;
                break;
        }

        if (builderCount < 10) {
            if (TextUtils.isDigitsOnly(text) || text.equals(".") || splitText.equals(":")) {
                if (splitText.equals(":")) {
                    operationBuilder.append(splitText);
                } else {
                    operationBuilder.append(text);
                }
            }
        }

        Log.i(TAG, "onClick: " + operationBuilder);
        Log.i(TAG, "onClick: " + operationList);

        if (/*text.equals("") ||*/ text.equals("clear")) {
            resultTextView.setText("0");
        } else {
            int count = builder.length();
            if (count < 10) {
                resultTextView.setText(builder.append(text));
            }
            if (count == 0 && text.equals("")) {
                resultTextView.setText("0");
            }

        }
    }

    private void insertData(double result) {
        DbHelper helper = new DbHelper(this);
        SQLiteDatabase db = helper.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(DbUtils.OPERATION_COLUMN, builder.toString());
        contentValues.put(DbUtils.MAIN_RESULTS_COLUMN, result);
        contentValues.put(DbUtils.DATE_COLUMN, System.currentTimeMillis());

        long rowId = db.insert(DbUtils.TABLE_NAME, null, contentValues);
        Log.i(TAG, "insertData: " + rowId);

    }

    private void removeLastChar(String s) {
        int count = builder.length();
        if (count > 0) {
//            builder.replace(count - 1, count, s);
            builder.deleteCharAt(builder.length() - 1);
        }
    }

    //Checks if last char is an operation or not
    private boolean checkOperationChar(int tag) {
        String lastChar = String.valueOf(builder.toString().charAt(builder.length() - 1));

        if (lastChar.equals("+") || lastChar.equals("-") ||
                lastChar.equals("×") || lastChar.equals("÷")) {
            if (operationList.size() > 0) {
                operationList.remove(operationList.size() - 1);
                operationList.add(tag);
            }
            return true;
        }
        return false;
    }

    private double doCalculation() {

        String[] numberStrings = operationBuilder.toString().split(":");

        if (numberStrings.length < 1 || numberStrings[0].equals("")) {
            return 0;
        }

        int l = numberStrings.length;
        Log.i(TAG, "doCalculation: " + l);

        double result = 0;
        int tag = 0;
        for (int i = 0; i < numberStrings.length; i++) {

            if (i == 0) {
                result = Double.parseDouble(numberStrings[0]);
                continue;
            }

            double num = Double.parseDouble(numberStrings[i]);

            if (operationList.size() > 0) {
                tag = operationList.get(0);
                operationList.remove(0);
            }

            switch (tag) {
                case OPERATION_ADD:
                    result += num;
                    break;
                case OPERATION_SUB:
                    result = result - num;
                    break;
                case OPERATION_MUL:
                    result = result * num;
                    break;
                case OPERATION_DIV:
                    result = result / num;
                    break;
            }

        }
        Log.i(TAG, "doCalculation: " + result);
        return result;
    }

}
