package developer.code.kpchandora.calcdemo;

public class DbUtils {

    public static final String TABLE_NAME = "table_calculator";
    public static final String _ID = "calc_id";
    public static final String OPERATION_COLUMN = "operation_column";
    public static final String MAIN_RESULTS_COLUMN = "main_results";
    public static final String DATE_COLUMN = "date_column";

}
