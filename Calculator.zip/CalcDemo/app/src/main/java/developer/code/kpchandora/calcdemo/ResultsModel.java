package developer.code.kpchandora.calcdemo;

public class ResultsModel {

    private String operations;
    private String mainResult;

    public String getOperations() {
        return operations;
    }

    public void setOperations(String operations) {
        this.operations = operations;
    }

    public String getMainResult() {
        return mainResult;
    }

    public void setMainResult(String mainResult) {
        this.mainResult = mainResult;
    }
}
